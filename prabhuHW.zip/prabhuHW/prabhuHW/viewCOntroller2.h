//
//  viewCOntroller2.h
//  prabhuHW
//
//  Created by Mobile App Developer on 8/19/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface viewCOntroller2 : UIView

@end
