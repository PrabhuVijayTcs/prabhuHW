//
//  viewCOntroller2.m
//  prabhuHW
//
//  Created by Mobile App Developer on 8/19/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import "viewCOntroller2.h"

@implementation viewCOntroller2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
