//
//  AppDelegate.h
//  prabhuHW
//
//  Created by Mobile App Developer on 8/18/14.
//  Copyright (c) 2014 Test. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
